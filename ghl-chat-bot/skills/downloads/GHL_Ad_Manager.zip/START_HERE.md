# Start here

1. Read SOP.md for the operating procedure.
2. The skills folder contains the reusable skills and their references. Copy the named skill folders inside it into your tool's skills directory. For Codex on Windows, use %USERPROFILE%\.codex\skills unless CODEX_HOME points elsewhere. Compare existing customized skills before replacing them.
3. Start a new session and invoke the desired skill by name, for example $ghl-facebook-ads or $ghl-agent-test, with your business, target, and requested work.
4. For repository storage, copy the skill folders under ghl-chat-bot/skills and keep SOP.md with the package. Review repository instructions and commit only these files.

These instructions do not grant GHL access or browser control. The other computer must have authorized tools and a logged-in account. No credentials or customer histories are included.